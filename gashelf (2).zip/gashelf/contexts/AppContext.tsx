import React, { createContext, useState, ReactNode, useEffect } from 'react';
import { User, Book, BorrowRecord, UserRole, BookStatus } from '../types';

const PLACEHOLDER_IMAGE_URL = 'https://placehold.co/100x150/6366f1/white?text=Book';

// In a real app, this data would come from a database.
const initialBooks: Book[] = [
  { id: 'b1', title: 'Database System Concepts', author: 'Silberschatz, Korth', status: BookStatus.AVAILABLE, imageUrl: PLACEHOLDER_IMAGE_URL },
  { id: 'b2', title: 'Clean Code', author: 'Robert C. Martin', status: BookStatus.AVAILABLE, imageUrl: PLACEHOLDER_IMAGE_URL },
  { id: 'b3', title: 'The Pragmatic Programmer', author: 'Hunt, Thomas', status: BookStatus.BORROWED, imageUrl: PLACEHOLDER_IMAGE_URL },
  { id: 'b4', title: 'Introduction to Algorithms', author: 'CLRS', status: BookStatus.AVAILABLE, imageUrl: PLACEHOLDER_IMAGE_URL },
  { id: 'b5', title: 'Designing Data-Intensive Applications', author: 'Martin Kleppmann', status: BookStatus.AVAILABLE, imageUrl: PLACEHOLDER_IMAGE_URL },
];

const initialUsers: User[] = [
    { id: 'u1', name: 'Admin', usn: 'ADMIN', password_hash: 'admin123', role: UserRole.ADMIN },
    { id: 'u2', name: 'John Doe', usn: '1AB123', password_hash: 'student123', role: UserRole.STUDENT },
];

const initialBorrowRecords: BorrowRecord[] = [
    { id: 'br1', bookId: 'b3', userId: 'u2', borrowDate: new Date(new Date().setDate(new Date().getDate() - 10)), dueDate: new Date(new Date().setDate(new Date().getDate() + 4)) },
];

interface AppContextType {
  users: User[];
  books: Book[];
  borrowRecords: BorrowRecord[];
  currentUser: User | null;
  login: (usn: string, password_hash: string) => boolean;
  logout: () => void;
  signup: (name: string, usn: string, password_hash: string) => boolean;
  addBook: (title: string, author: string) => void;
  removeBook: (bookId: string) => void;
  borrowBook: (bookId: string, durationDays: number) => void;
  returnBook: (bookId: string) => void;
  updateBookDetails: (bookId: string, title: string, author: string, imageUrl: string) => void;
  updateBookStatus: (bookId: string, status: BookStatus) => void;
}

export const AppContext = createContext<AppContextType | null>(null);

export const AppProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [users, setUsers] = useState<User[]>(initialUsers);
  const [books, setBooks] = useState<Book[]>(initialBooks);
  const [borrowRecords, setBorrowRecords] = useState<BorrowRecord[]>(initialBorrowRecords);
  const [currentUser, setCurrentUser] = useState<User | null>(null);

  useEffect(() => {
    const storedUser = localStorage.getItem('currentUser');
    if (storedUser) {
      setCurrentUser(JSON.parse(storedUser));
    }
  }, []);

  const login = (usn: string, password_hash: string): boolean => {
    const user = users.find(u => u.usn.toLowerCase() === usn.toLowerCase() && u.password_hash === password_hash);
    if (user) {
      setCurrentUser(user);
      localStorage.setItem('currentUser', JSON.stringify(user));
      return true;
    }
    return false;
  };

  const logout = () => {
    setCurrentUser(null);
    localStorage.removeItem('currentUser');
  };

  const signup = (name: string, usn: string, password_hash: string): boolean => {
    if (users.some(u => u.usn.toLowerCase() === usn.toLowerCase())) {
      return false; // User with this USN already exists
    }
    const newUser: User = {
      id: `u${Date.now()}`, // Use timestamp for unique ID
      name,
      usn,
      password_hash,
      role: UserRole.STUDENT,
    };
    setUsers(prev => [...prev, newUser]);
    login(usn, password_hash);
    return true;
  };

  const addBook = (title: string, author: string) => {
    const newBook: Book = {
      id: `b${books.length + 1}`,
      title,
      author,
      status: BookStatus.AVAILABLE,
      imageUrl: PLACEHOLDER_IMAGE_URL,
    };
    setBooks(prev => [...prev, newBook]);
  };
  
  const removeBook = (bookId: string) => {
    // In a real system, you might archive instead of delete
    setBooks(prev => prev.filter(b => b.id !== bookId));
  };

  const borrowBook = (bookId: string, durationDays: number) => {
    if (!currentUser) return;
    setBooks(prev => prev.map(b => b.id === bookId ? { ...b, status: BookStatus.BORROWED } : b));
    
    const borrowDate = new Date();
    const dueDate = new Date(borrowDate);
    dueDate.setDate(borrowDate.getDate() + durationDays);
    
    const newRecord: BorrowRecord = {
      id: `br${borrowRecords.length + 1}`,
      bookId,
      userId: currentUser.id,
      borrowDate,
      dueDate,
    };
    setBorrowRecords(prev => [...prev, newRecord]);
  };

  const returnBook = (bookId: string) => {
    if (!currentUser) return;
    setBooks(prev => prev.map(b => b.id === bookId ? { ...b, status: BookStatus.AVAILABLE } : b));
    setBorrowRecords(prev => prev.map(br => (br.bookId === bookId && br.userId === currentUser.id && !br.returnDate) ? { ...br, returnDate: new Date() } : br));
  };

  const updateBookDetails = (bookId: string, title: string, author: string, imageUrl: string) => {
    setBooks(prev => prev.map(b => b.id === bookId ? { ...b, title, author, imageUrl } : b));
  };

  const updateBookStatus = (bookId: string, status: BookStatus) => {
    setBooks(prev => prev.map(b => b.id === bookId ? { ...b, status } : b));
  };

  return (
    <AppContext.Provider value={{ users, books, borrowRecords, currentUser, login, logout, signup, addBook, removeBook, borrowBook, returnBook, updateBookDetails, updateBookStatus }}>
      {children}
    </AppContext.Provider>
  );
};