export enum UserRole {
  STUDENT = 'STUDENT',
  ADMIN = 'ADMIN',
}

export enum BookStatus {
  AVAILABLE = 'AVAILABLE',
  BORROWED = 'BORROWED',
  LOST = 'LOST',
  DAMAGED = 'DAMAGED',
}

export interface User {
  id: string;
  name: string;
  usn: string; // University Serial Number
  password_hash: string; // In a real app, this would be a hash
  role: UserRole;
}

export interface Book {
  id: string;
  title: string;
  author: string;
  status: BookStatus;
  imageUrl?: string;
}

export interface BorrowRecord {
  id: string;
  bookId: string;
  userId: string;
  borrowDate: Date;
  dueDate: Date;
  returnDate?: Date;
}

export interface ChatMessage {
    id: string;
    text: string;
    sender: 'user' | 'bot';
}