import { GoogleGenAI, FunctionDeclaration, Type, Part } from "@google/genai";
import { ChatMessage, Book, User, BorrowRecord, BookStatus } from '../types';


// Prefer Vite env var (VITE_GEMINI_API_KEY) when running in the browser/dev server.
// Fall back to process.env.GEMINI_API_KEY for Node-side usage.
const API_KEY = (typeof (import.meta as any) !== 'undefined' && (import.meta as any).env && (import.meta as any).env.VITE_GEMINI_API_KEY) || process.env.GEMINI_API_KEY;

if (!API_KEY) {
  console.warn("GEMINI_API_KEY environment variable not set. Chatbot will not work.");
}

let ai: GoogleGenAI | null = null;
const model = 'gemini-1.5-flash';

if (API_KEY) {
  try {
    ai = new GoogleGenAI({ apiKey: API_KEY });
  } catch (err) {
    // If the library refuses to initialize in the browser (or any other reason),
    // log and keep ai as null so the rest of the app can function.
    console.warn('Failed to initialize GoogleGenAI client:', err);
    ai = null;
  }
}

// --- Tool Definitions for Gemini ---

const getBookStatusTool: FunctionDeclaration = {
  name: 'getBookStatus',
  description: 'Get the current status of a specific book (e.g., AVAILABLE, BORROWED, LOST, DAMAGED).',
  parameters: {
    type: Type.OBJECT,
    properties: {
      bookTitle: {
        type: Type.STRING,
        description: 'The title of the book to check.',
      },
    },
    required: ['bookTitle'],
  },
};

const getAvailableBooksTool: FunctionDeclaration = {
  name: 'getAvailableBooks',
  description: 'Get a list of all books that are currently available for borrowing.',
  parameters: { type: Type.OBJECT, properties: {} },
};

const getMyBorrowedBooksTool: FunctionDeclaration = {
  name: 'getMyBorrowedBooks',
  description: "Get a list of books currently borrowed by the user, including their due dates. This function knows who the current user is.",
  parameters: { type: Type.OBJECT, properties: {} },
};

const tools = [{ functionDeclarations: [getBookStatusTool, getAvailableBooksTool, getMyBorrowedBooksTool] }];

// --- Local Implementations of Tools ---

const findBookStatus = (bookTitle: string, allBooks: Book[]): string => {
  const book = allBooks.find(b => b.title.toLowerCase().includes(bookTitle.toLowerCase()));
  if (book) {
    return `The book "${book.title}" is currently ${book.status}.`;
  }
  return `Sorry, I could not find a book with the title "${bookTitle}". Please check the spelling.`;
};

const findAvailableBooks = (allBooks: Book[]): string => {
  const availableBooks = allBooks.filter(b => b.status === BookStatus.AVAILABLE);
  if (availableBooks.length > 0) {
    const titles = availableBooks.map(b => `"${b.title}"`).join(', ');
    return `The following books are available: ${titles}.`;
  }
  return 'There are currently no books available for borrowing.';
};

const findMyBorrowedBooks = (currentUser: User | null, allBooks: Book[], allRecords: BorrowRecord[]): string => {
    if (!currentUser) {
        return "I can't check your borrowed books because you are not logged in.";
    }
    const myRecords = allRecords.filter(r => r.userId === currentUser.id && !r.returnDate);
    if (myRecords.length > 0) {
        const bookDetails = myRecords.map(record => {
            const book = allBooks.find(b => b.id === record.bookId);
            return `"${book?.title || 'Unknown Book'}" (Due: ${record.dueDate.toLocaleDateString()})`;
        }).join('; ');
        return `You have borrowed the following books: ${bookDetails}.`;
    }
    return "You have not borrowed any books currently.";
}

// --- Main Chatbot Service ---

interface AppState {
    books: Book[];
    currentUser: User | null;
    borrowRecords: BorrowRecord[];
}

export const getChatbotResponse = async (history: ChatMessage[], newPrompt: string, appState: AppState): Promise<string> => {
  // If the client isn't available, return a graceful fallback instead of
  // attempting to call the API from the browser.
  if (!ai) {
    return "I can't respond right now. The API key is not configured or the chatbot client couldn't be initialized.";
  }
  
  try {
    const contents = [
      ...history.map(msg => ({
        role: msg.sender === 'user' ? 'user' : 'model',
        parts: [{ text: msg.text }],
      })),
      { role: 'user', parts: [{ text: newPrompt }] },
    ];

    // The typed declaration for generateContent may not include our 'tools' property
    // in this environment, and some fields (like functionCall.args) may be typed
    // as unknown. Use casts/ignores to avoid blocking the dev build while keeping
    // the runtime behavior.
    // @ts-ignore - keep runtime 'tools' support
    const response = await (ai as any).models.generateContent({
      model: model,
      contents: contents,
      tools: tools,
      config: {
        systemInstruction: "You are a helpful and friendly library assistant chatbot for the 'GaShelf' application. Your role is to answer questions. You have access to tools that can check the library's live database for real-time information. Use these tools whenever a user asks about book availability, their borrowed books, or what books are in the library. For general knowledge questions, answer them directly.",
      }
    });
    
    const responsePart = response.candidates?.[0]?.content.parts[0];

    if (responsePart?.functionCall) {
  const functionCall = responsePart.functionCall;
  const { name } = functionCall;
  // functionCall.args may be typed as unknown depending on the SDK; cast to any
  const argsAny = (functionCall as any).args as any;
  let functionResult: string;
        
  console.log(`Executing tool: ${name}`, argsAny);

        // Execute the appropriate local function
    switch (name) {
      case 'getBookStatus':
        functionResult = findBookStatus(argsAny.bookTitle, appState.books);
        break;
      case 'getAvailableBooks':
        functionResult = findAvailableBooks(appState.books);
        break;
      case 'getMyBorrowedBooks':
        functionResult = findMyBorrowedBooks(appState.currentUser, appState.books, appState.borrowRecords);
        break;
            default:
                functionResult = "Sorry, I can't use that tool right now.";
        }

        // Add the function call and its result to the conversation history
        const newContents = [
            ...contents,
            { role: 'model', parts: [responsePart] }, // The model's request to call a function
            {
                role: 'function',
                parts: [{
                    functionResponse: {
                        name: name,
                        response: { result: functionResult }
                    }
                }]
            } // Your code's response from the tool
        ];

        // Send the updated history back to the model to get a natural language response
     // @ts-ignore - include tools for the follow-up call as well
     const finalResponse = await (ai as any).models.generateContent({
       model: model,
       contents: newContents,
       tools: tools,
     });

     return (finalResponse as any).text;
    }

    // If no function call, return the text directly
    return response.text;

  } catch (error) {
    console.error("Error getting response from Gemini:", error);
    return "Sorry, I encountered an error while trying to respond. Please try again later.";
  }
};