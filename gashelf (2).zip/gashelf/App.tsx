
import React, { useContext } from 'react';
import { AppContext } from './contexts/AppContext';
import AuthScreen from './components/auth/AuthScreen';
import AdminDashboard from './components/admin/AdminDashboard';
import StudentDashboard from './components/student/StudentDashboard';
import Chatbot from './components/chatbot/Chatbot';
import Header from './components/shared/Header';
import { UserRole } from './types';

const App: React.FC = () => {
  const context = useContext(AppContext);

  if (!context) {
    return <div>Loading...</div>;
  }

  const { currentUser } = context;

  const renderDashboard = () => {
    if (!currentUser) {
      return <AuthScreen />;
    }

    switch (currentUser.role) {
      case UserRole.ADMIN:
        return <AdminDashboard />;
      case UserRole.STUDENT:
        return <StudentDashboard />;
      default:
        return <AuthScreen />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 text-gray-900 dark:text-gray-100 font-sans">
      {currentUser && <Header />}
      <main className="p-4 md:p-8">
        {renderDashboard()}
      </main>
      <Chatbot />
    </div>
  );
};

export default App;
