import React, { useState, useRef, useEffect, useContext } from 'react';
import { ChatIcon, CloseIcon, SendIcon, UserCircleIcon, BotIcon } from '../shared/icons';
import { getChatbotResponse } from '../../services/geminiService';
import { ChatMessage } from '../../types';
import { AppContext } from '../../contexts/AppContext';

const ChatBubble: React.FC<{ message: ChatMessage }> = ({ message }) => {
    const isUser = message.sender === 'user';
    return (
        <div className={`flex items-start gap-3 my-4 ${isUser ? 'justify-end' : 'justify-start'}`}>
            {!isUser && <BotIcon className="h-8 w-8 text-indigo-400 flex-shrink-0" />}
            <div className={`px-4 py-2 rounded-lg max-w-xs md:max-w-md ${isUser ? 'bg-indigo-500 text-white rounded-br-none' : 'bg-gray-200 dark:bg-gray-700 text-gray-800 dark:text-gray-200 rounded-bl-none'}`}>
                <p className="text-sm" dangerouslySetInnerHTML={{ __html: message.text.replace(/\n/g, '<br />') }}></p>
            </div>
            {isUser && <UserCircleIcon className="h-8 w-8 text-gray-400 flex-shrink-0" />}
        </div>
    );
};


const Chatbot: React.FC = () => {
    const context = useContext(AppContext);
    const [isOpen, setIsOpen] = useState(false);
    const [messages, setMessages] = useState<ChatMessage[]>([
        { id: '1', text: "Hello! I'm your smart library assistant. Feel free to ask about book availability, your borrowed books, or general topics.", sender: 'bot' }
    ]);
    const [userInput, setUserInput] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const chatboxRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        if (chatboxRef.current) {
            chatboxRef.current.scrollTop = chatboxRef.current.scrollHeight;
        }
    }, [messages]);

    const handleSendMessage = async () => {
        if (userInput.trim() === '' || isLoading || !context) return;
        
        const userMessage: ChatMessage = {
            id: Date.now().toString(),
            text: userInput,
            sender: 'user',
        };
        
        setMessages(prev => [...prev, userMessage]);
        setUserInput('');
        setIsLoading(true);

        try {
            const appState = {
                books: context.books,
                currentUser: context.currentUser,
                borrowRecords: context.borrowRecords
            };
            const botResponseText = await getChatbotResponse(messages, userInput, appState);
            const botMessage: ChatMessage = {
                id: (Date.now() + 1).toString(),
                text: botResponseText,
                sender: 'bot',
            };
            setMessages(prev => [...prev, botMessage]);
        } catch (error) {
            console.error("Failed to get bot response:", error);
            const errorMessage: ChatMessage = {
                 id: (Date.now() + 1).toString(),
                 text: "Sorry, I'm having trouble connecting. Please try again later.",
                 sender: 'bot',
            };
            setMessages(prev => [...prev, errorMessage]);
        } finally {
            setIsLoading(false);
        }
    };
    
    return (
        <>
            <button
                onClick={() => setIsOpen(true)}
                className={`fixed bottom-5 right-5 h-16 w-16 bg-indigo-600 rounded-full text-white flex items-center justify-center shadow-lg hover:bg-indigo-700 transition-transform transform hover:scale-110 ${isOpen ? 'hidden' : 'block'}`}
            >
                <ChatIcon className="h-8 w-8" />
            </button>

            <div className={`fixed bottom-5 right-5 w-full max-w-sm h-full max-h-[70vh] bg-white dark:bg-gray-800 rounded-xl shadow-2xl flex flex-col transition-all duration-300 ease-in-out ${isOpen ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10 pointer-events-none'}`}>
                <header className="p-4 bg-indigo-600 text-white flex justify-between items-center rounded-t-xl">
                    <h3 className="font-bold text-lg">Library Assistant</h3>
                    <button onClick={() => setIsOpen(false)} className="p-1 rounded-full hover:bg-indigo-500">
                        <CloseIcon className="h-6 w-6" />
                    </button>
                </header>

                <div ref={chatboxRef} className="flex-1 p-4 overflow-y-auto">
                    {messages.map(msg => <ChatBubble key={msg.id} message={msg} />)}
                     {isLoading && (
                        <div className="flex items-start gap-3 my-4 justify-start">
                            <BotIcon className="h-8 w-8 text-indigo-400 flex-shrink-0" />
                            <div className="px-4 py-2 rounded-lg bg-gray-200 dark:bg-gray-700 rounded-bl-none">
                                <div className="flex items-center space-x-1">
                                    <span className="h-2 w-2 bg-gray-500 rounded-full animate-pulse [animation-delay:-0.3s]"></span>
                                    <span className="h-2 w-2 bg-gray-500 rounded-full animate-pulse [animation-delay:-0.15s]"></span>
                                    <span className="h-2 w-2 bg-gray-500 rounded-full animate-pulse"></span>
                                </div>
                            </div>
                        </div>
                    )}
                </div>

                <div className="p-4 border-t border-gray-200 dark:border-gray-700">
                    <div className="flex items-center space-x-2">
                        <input
                            type="text"
                            value={userInput}
                            onChange={(e) => setUserInput(e.target.value)}
                            onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                            placeholder="Ask a question..."
                            className="flex-1 px-3 py-2 bg-gray-100 dark:bg-gray-700 border border-transparent rounded-full focus:outline-none focus:ring-2 focus:ring-indigo-500"
                        />
                        <button onClick={handleSendMessage} disabled={isLoading} className="p-3 bg-indigo-600 text-white rounded-full hover:bg-indigo-700 disabled:bg-indigo-300 disabled:cursor-not-allowed">
                            <SendIcon className="h-5 w-5" />
                        </button>
                    </div>
                </div>
            </div>
        </>
    );
};

export default Chatbot;