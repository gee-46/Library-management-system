
import React, { useContext } from 'react';
import { AppContext } from '../../contexts/AppContext';
import { BookStatus } from '../../types';

const StudentDashboard: React.FC = () => {
    const context = useContext(AppContext);

    if (!context) return <div>Loading...</div>;

    const { books, currentUser, borrowRecords, borrowBook, returnBook } = context;

    if (!currentUser) return <div>Please log in.</div>;

    const myBorrowedRecords = borrowRecords.filter(r => r.userId === currentUser.id && !r.returnDate);
    const availableBooks = books.filter(b => b.status === BookStatus.AVAILABLE);

    return (
        <div className="space-y-8">
            <h2 className="text-3xl font-bold">Welcome, {currentUser.name}!</h2>

            {/* My Borrowed Books */}
            <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow">
                <h3 className="text-xl font-semibold mb-4">My Borrowed Books</h3>
                {myBorrowedRecords.length > 0 ? (
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                        {myBorrowedRecords.map(record => {
                            const book = books.find(b => b.id === record.bookId);
                            if (!book) return null;
                            const isOverdue = new Date() > record.dueDate;
                            return (
                                <div key={record.id} className="border dark:border-gray-700 rounded-lg p-4 flex flex-col">
                                    <img src={book.imageUrl} alt={book.title} className="h-40 w-28 object-cover self-center mb-4 rounded"/>
                                    <h4 className="font-bold text-lg">{book.title}</h4>
                                    <p className="text-sm text-gray-600 dark:text-gray-400 mb-2">by {book.author}</p>
                                    <p className={`text-sm ${isOverdue ? 'text-red-500 font-bold' : ''}`}>
                                        Due Date: <span className="font-semibold">{record.dueDate.toLocaleDateString()}</span>
                                    </p>
                                    <button onClick={() => returnBook(book.id)} className="mt-auto w-full px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 mt-4">Return Book</button>
                                </div>
                            );
                        })}
                    </div>
                ) : (
                    <p className="text-gray-600 dark:text-gray-400">You haven't borrowed any books yet. Check out the available books below!</p>
                )}
            </div>

            {/* Available Books for Borrowing */}
            <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow">
                <h3 className="text-xl font-semibold mb-4">Available Books</h3>
                {availableBooks.length > 0 ? (
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                        {availableBooks.map(book => (
                            <div key={book.id} className="border dark:border-gray-700 rounded-lg p-4 flex flex-col text-center">
                                <img src={book.imageUrl} alt={book.title} className="h-40 w-28 object-cover self-center mb-4 rounded"/>
                                <h4 className="font-bold text-lg">{book.title}</h4>
                                <p className="text-sm text-gray-600 dark:text-gray-400 mb-2">by {book.author}</p>
                                <button onClick={() => borrowBook(book.id, 14)} className="mt-auto w-full px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700">Borrow (14 days)</button>
                            </div>
                        ))}
                    </div>
                ) : (
                    <p className="text-gray-600 dark:text-gray-400">No books are available for borrowing at the moment.</p>
                )}
            </div>
        </div>
    );
};

export default StudentDashboard;
