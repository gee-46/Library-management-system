
import React, { useContext, useState } from 'react';
import { AppContext } from '../../contexts/AppContext';
import { Book, BookStatus } from '../../types';
import { PencilIcon } from '../shared/icons';

// Modal component for editing a book
const EditBookModal: React.FC<{
  book: Book;
  onClose: () => void;
  onSave: (bookId: string, title: string, author: string, imageUrl: string) => void;
}> = ({ book, onClose, onSave }) => {
  const [title, setTitle] = useState(book.title);
  const [author, setAuthor] = useState(book.author);
  const [imageUrl, setImageUrl] = useState(book.imageUrl || '');

  const handleSave = () => {
    onSave(book.id, title, author, imageUrl);
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50">
      <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-xl w-full max-w-md">
        <h3 className="text-lg font-bold mb-4">Edit Book</h3>
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Title</label>
            <input type="text" value={title} onChange={(e) => setTitle(e.target.value)} className="mt-1 block w-full rounded-md border-gray-300 dark:border-gray-600 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm bg-gray-50 dark:bg-gray-700 p-2" />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Author</label>
            <input type="text" value={author} onChange={(e) => setAuthor(e.target.value)} className="mt-1 block w-full rounded-md border-gray-300 dark:border-gray-600 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm bg-gray-50 dark:bg-gray-700 p-2" />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">Image URL</label>
            <input type="text" value={imageUrl} onChange={(e) => setImageUrl(e.target.value)} className="mt-1 block w-full rounded-md border-gray-300 dark:border-gray-600 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm bg-gray-50 dark:bg-gray-700 p-2" />
          </div>
        </div>
        <div className="mt-6 flex justify-end space-x-2">
          <button onClick={onClose} className="px-4 py-2 bg-gray-200 dark:bg-gray-600 rounded-md hover:bg-gray-300 dark:hover:bg-gray-500">Cancel</button>
          <button onClick={handleSave} className="px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700">Save</button>
        </div>
      </div>
    </div>
  );
};

const AdminDashboard: React.FC = () => {
  const context = useContext(AppContext);
  const [newBookTitle, setNewBookTitle] = useState('');
  const [newBookAuthor, setNewBookAuthor] = useState('');
  const [editingBook, setEditingBook] = useState<Book | null>(null);

  if (!context) return <div>Loading...</div>;
  const { books, users, borrowRecords, addBook, removeBook, updateBookDetails, updateBookStatus } = context;

  const handleAddBook = (e: React.FormEvent) => {
    e.preventDefault();
    if (newBookTitle && newBookAuthor) {
      addBook(newBookTitle, newBookAuthor);
      setNewBookTitle('');
      setNewBookAuthor('');
    }
  };

  const getUserName = (userId: string) => users.find(u => u.id === userId)?.name || 'Unknown User';
  const getBookTitle = (bookId: string) => books.find(b => b.id === bookId)?.title || 'Unknown Book';

  return (
    <div className="space-y-8">
      <h2 className="text-3xl font-bold">Admin Dashboard</h2>

      {/* Manage Books */}
      <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow">
        <h3 className="text-xl font-semibold mb-4">Manage Books</h3>
        <form onSubmit={handleAddBook} className="flex flex-col md:flex-row gap-4 mb-6">
          <input type="text" placeholder="Book Title" value={newBookTitle} onChange={e => setNewBookTitle(e.target.value)} className="flex-grow p-2 border rounded-md dark:bg-gray-700 dark:border-gray-600" required />
          <input type="text" placeholder="Author" value={newBookAuthor} onChange={e => setNewBookAuthor(e.target.value)} className="flex-grow p-2 border rounded-md dark:bg-gray-700 dark:border-gray-600" required />
          <button type="submit" className="px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700">Add Book</button>
        </form>
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead>
              <tr className="border-b dark:border-gray-700">
                <th className="p-2">Title</th>
                <th className="p-2">Author</th>
                <th className="p-2">Status</th>
                <th className="p-2">Actions</th>
              </tr>
            </thead>
            <tbody>
              {books.map(book => (
                <tr key={book.id} className="border-b dark:border-gray-700">
                  <td className="p-2">{book.title}</td>
                  <td className="p-2">{book.author}</td>
                  <td className="p-2">
                    <select value={book.status} onChange={e => updateBookStatus(book.id, e.target.value as BookStatus)} className="p-1 border rounded-md dark:bg-gray-700 dark:border-gray-600">
                      {Object.values(BookStatus).map(status => <option key={status} value={status}>{status}</option>)}
                    </select>
                  </td>
                  <td className="p-2 flex gap-2">
                    <button onClick={() => setEditingBook(book)} className="p-2 text-blue-500 hover:text-blue-700"><PencilIcon className="h-5 w-5" /></button>
                    <button onClick={() => window.confirm('Are you sure you want to delete this book?') && removeBook(book.id)} className="px-3 py-1 bg-red-500 text-white rounded-md hover:bg-red-600 text-sm">Delete</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Users List */}
      <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow">
        <h3 className="text-xl font-semibold mb-4">Users</h3>
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead>
              <tr className="border-b dark:border-gray-700"><th className="p-2">Name</th><th className="p-2">USN</th><th className="p-2">Role</th></tr>
            </thead>
            <tbody>
              {users.map(user => (
                <tr key={user.id} className="border-b dark:border-gray-700"><td className="p-2">{user.name}</td><td className="p-2">{user.usn}</td><td className="p-2">{user.role}</td></tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Borrow Records */}
      <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow">
        <h3 className="text-xl font-semibold mb-4">Borrowing History</h3>
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead>
              <tr className="border-b dark:border-gray-700"><th className="p-2">Book</th><th className="p-2">User</th><th className="p-2">Borrowed</th><th className="p-2">Due</th><th className="p-2">Returned</th></tr>
            </thead>
            <tbody>
              {borrowRecords.sort((a,b) => b.borrowDate.getTime() - a.borrowDate.getTime()).map(record => (
                <tr key={record.id} className="border-b dark:border-gray-700">
                  <td className="p-2">{getBookTitle(record.bookId)}</td>
                  <td className="p-2">{getUserName(record.userId)}</td>
                  <td className="p-2">{record.borrowDate.toLocaleDateString()}</td>
                  <td className="p-2">{record.dueDate.toLocaleDateString()}</td>
                  <td className="p-2">{record.returnDate ? record.returnDate.toLocaleDateString() : 'Not Returned'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {editingBook && <EditBookModal book={editingBook} onClose={() => setEditingBook(null)} onSave={updateBookDetails} />}
    </div>
  );
};

export default AdminDashboard;
