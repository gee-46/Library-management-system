<div align="center">
<img width="1200" height="475" alt="GHBanner" src="https://github.com/user-attachments/assets/0aa67016-6eaf-458a-adb2-6e31a0763ed6" />
</div>

# Gashelf

Gashelf is an AI-powered educational platform built with React and TypeScript, integrating Google's Gemini AI for enhanced learning experiences. It features dashboards for students and admins, a chatbot for interactive assistance, and secure authentication.

## Features

- **Student Dashboard**: Personalized learning interface for students.
- **Admin Dashboard**: Management tools for administrators.
- **AI Chatbot**: Powered by Gemini AI for real-time assistance.
- **Authentication**: Secure login and user management.
- **Responsive Design**: Optimized for various devices.

## Tech Stack

- **Frontend**: React 19, TypeScript, Vite
- **AI Integration**: Google Gemini API
- **Styling**: CSS
- **Build Tool**: Vite

## Installation

**Prerequisites:** Node.js (version 16 or higher)

1. Clone the repository:
   ```bash
   git clone https://github.com/your-username/gashelf.git
   cd gashelf
   ```

2. Install dependencies:
   ```bash
   npm install
   ```

3. Set up environment variables:
   - Copy `.env.example` to `.env.local`:
     ```bash
     cp .env.example .env.local
     ```
   - Add your Gemini API key to `.env.local`:
     ```
     VITE_GEMINI_API_KEY=your_gemini_api_key_here
     ```

4. Run the development server:
   ```bash
   npm run dev
   ```

The app will be available at `http://localhost:5173`.

## Usage

- Access the app in your browser after running `npm run dev`.
- Log in as a student or admin to explore the dashboards.
- Interact with the AI chatbot for assistance.

**Important Security Note:**  
Using the Gemini API key directly from the client (browser) is insecure for production. For production deployments, implement a server-side proxy to handle API requests securely.

## Contributing

Contributions are welcome! Please follow these steps:

1. Fork the repository.
2. Create a new branch for your feature: `git checkout -b feature/your-feature-name`.
3. Make your changes and commit them: `git commit -m 'Add some feature'`.
4. Push to the branch: `git push origin feature/your-feature-name`.
5. Open a pull request.

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.
